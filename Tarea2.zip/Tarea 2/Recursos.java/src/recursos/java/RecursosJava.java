/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recursos.java;
import java.util.ArrayList;
import java.util.List;

// Definir la clase Recursos
public class Recursos {

    // Primer método: Retornar un mensaje específico
    public String mensajePOO() {
        return "Programación Orientada a Objetos 2021";
    }

    // Segundo método: Determinar si es mayor o menor de edad
    public String verificarEdad(int edad) {
        if (edad >= 21) {
            return "Mayor de edad";
        } else {
            return "Menor de edad";
        }
    }

    // Tercer método: Retornar el resultado de una multiplicación
    public int multiplicar(int a, int b) {
        return a * b;
    }

    // Cuarto método: Retornar una lista de números del 1 al X
    public List<Integer> listaNumeros(int x) {
        List<Integer> lista = new ArrayList<>();
        for (int i = 1; i <= x; i++) {
            lista.add(i);
        }
        return lista;
    }
}
public class RecursosJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
